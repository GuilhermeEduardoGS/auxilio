package github.britooo.mocks.dto;

public class OrcamentoRequest {

    private Integer quantidade;
    private Double precoUnitario;
}

