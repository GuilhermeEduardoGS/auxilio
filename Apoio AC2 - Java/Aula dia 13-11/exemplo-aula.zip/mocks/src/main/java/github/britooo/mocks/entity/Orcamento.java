package github.britooo.mocks.entity;

import jakarta.persistence.*;

@Entity
public class Orcamento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String codigo;
    private Integer quantidade;
    private Double precoUnitario;
    private Double valorTotal;
}
