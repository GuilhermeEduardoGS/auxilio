package github.britooo.mocks.service;

import github.britooo.mocks.dto.OrcamentoRequest;
import github.britooo.mocks.dto.OrcamentoResponse;
import github.britooo.mocks.entity.Orcamento;
import github.britooo.mocks.repository.OrcamentoRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrcamentoService {

    private final OrcamentoRepository repository;

    public OrcamentoService(OrcamentoRepository repository) {
        this.repository = repository;
    }

    public List<Orcamento> listarOrcamentos() {
        return repository.findAll();
    }

    public Orcamento buscarPorCodigo(String codigo) {
        return null;
    }

    public OrcamentoResponse criarOrcamento(OrcamentoRequest req) {
        return null;
    }
}
