package github.britooo.mocks.dto;

public class OrcamentoResponse {

    private String codigo;
    private Double valorTotal;
}