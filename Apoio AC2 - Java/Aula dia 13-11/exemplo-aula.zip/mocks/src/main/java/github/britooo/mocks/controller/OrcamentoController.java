package github.britooo.mocks.controller;

import github.britooo.mocks.dto.OrcamentoRequest;
import github.britooo.mocks.dto.OrcamentoResponse;
import github.britooo.mocks.service.OrcamentoService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/orcamentos")
public class OrcamentoController {

    private final OrcamentoService service;

    public OrcamentoController(OrcamentoService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<OrcamentoResponse> criar(@RequestBody OrcamentoRequest request) {
        return null;
    }

    @GetMapping("/{codigo}")
    public ResponseEntity<OrcamentoResponse> buscarPorCodigo(@PathVariable String codigo) {
        return null;
    }

    @GetMapping
    public ResponseEntity<List<OrcamentoResponse>> listar() {
        return null;
    }
}
