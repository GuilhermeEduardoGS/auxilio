# Objetivo: Desenvolver uma aplicação CRUD simples para gerenciar usuários.

## Instruções:

Você deverá criar um sistema de gerenciamento de usuários com os seguintes endpoints:

### 1. Cadastro de usuário (máximo de 3 pontos)

Parâmetros: Recebe um objeto Usuario, exemplo:
```json
{	
    "nome": "POST Malone",
    "email": "post@malone.com",
    "senha": "post123",
    "dataNascimento": "1995-07-04"
}
```
Objetivo: Adicionar um novo usuário.

- Validações:
    - O campo e-mail é obrigatório, deve conter no mínimo 10 caracteres e ter pelo menos um “@”.
    - O e-mail fornecido não deve existir na lista de usuários.

Forneça uma resposta (código http) adequada para cada situação. A senha não deve ser retornada na resposta.

<hr>

### 2. Listagem de todos os usuários (máximo de 1 ponto)
Objetivo: Retornar uma lista com todos os usuários cadastrados.

Exemplo de resposta:
```json
[
    {	
        "id": 1,	
        "nome": "GET Malone",
        "email": "get@malone.com",
        "dataNascimento": "1995-07-04"
    }
]
```
Forneça uma resposta (código http) adequada para cada situação.
<hr>

### 3. Buscar usuário por ID (máximo de 1 ponto)

Parâmetros: Recebe um ID como parâmetro.

Objetivo: Retornar os dados de um usuário com base em seu ID. 

Exemplo de resposta:
```json
{	
    "id": 1,	
    "nome": "GET Malone",
    "email": "get@malone.com",
    "dataNascimento": "1995-07-04"
}
```

Forneça uma resposta (código http) adequada para cada situação.
<hr>

### 4. Atualização de usuário por ID (máximo de 2,5 pontos)

Parâmetros: Recebe um ID e um objeto Usuario atualizado.

Objetivo: Atualizar os dados de um usuário existente.
- Validações:
    - O campo e-mail é obrigatório, não deve ser nulo, deve conter no mínimo 10 caracteres e ter pelo menos um “@”.
    - Certifique-se de que o novo e-mail não exista na lista de usuários, ou seja, não está cadastrado para outro usuário.

Fornecer uma resposta (código http) adequada para cada situação.
<hr>

### 5. Exclusão de usuário por ID (máximo de 2,5 pontos)

Parâmetros: Recebe um ID como parâmetro.

Objetivo: Remover um usuário da lista com base em seu ID.

Fornecer uma resposta (código http) adequada para cada situação.

<hr>

### Especificações do Modelo:
O usuário deve possuir os seguintes campos:

- id: int
- email: String
- nome: String
- senha: String
- dataNascimento: LocalDate

<hr>