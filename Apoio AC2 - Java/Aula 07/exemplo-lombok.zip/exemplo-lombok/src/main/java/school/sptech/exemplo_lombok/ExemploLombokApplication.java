package school.sptech.exemplo_lombok;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExemploLombokApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExemploLombokApplication.class, args);
	}

}
