package school.sptech.exemplo_curso.dto.aluno;

import school.sptech.exemplo_curso.entity.aluno.Aluno;

import java.util.List;

public class AlunoMapper {

    public static AlunoResponseDto toAlunoResponseDto(Aluno alunoEntity) {
        if (alunoEntity == null) {
            return null;
        }

        AlunoCursoResponseDto cursoDto = alunoEntity.getCurso() != null
                ? new AlunoCursoResponseDto(alunoEntity.getCurso().getId(), alunoEntity.getCurso().getNome())
                : null;

        return new AlunoResponseDto(
                alunoEntity.getId(),
                alunoEntity.getRa(),
                alunoEntity.getNome(),
                cursoDto
        );
    }

    public static List<AlunoResponseDto> toAlunoResponseDto(List<Aluno> entities) {
        if (entities == null) {
            return null;
        }

        return entities.stream()
                .map(AlunoMapper::toAlunoResponseDto)
                .toList();
    }

    public static Aluno toEntity(AlunoCadastroDto dto) {
        if (dto == null) {
            return null;
        }

        return Aluno.builder()
                .ra(dto.ra())
                .nome(dto.nome())
                .build();
    }
}
