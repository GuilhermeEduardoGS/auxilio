package school.sptech.exemplo_curso.dto.aluno;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AlunoResponseDto {
    private Integer id;
    private String ra;
    private String nome;
    private AlunoCursoResponseDto curso; // Que traz os dados relacionados
}
