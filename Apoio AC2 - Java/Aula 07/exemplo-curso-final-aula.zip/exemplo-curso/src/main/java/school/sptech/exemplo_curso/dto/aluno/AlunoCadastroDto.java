package school.sptech.exemplo_curso.dto.aluno;

public record AlunoCadastroDto(
        String ra,
        String nome,
        int cursoId
) {
}
