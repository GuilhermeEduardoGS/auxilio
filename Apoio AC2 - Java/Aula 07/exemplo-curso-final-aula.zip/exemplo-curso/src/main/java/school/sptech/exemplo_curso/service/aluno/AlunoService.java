package school.sptech.exemplo_curso.service.aluno;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import school.sptech.exemplo_curso.entity.aluno.Aluno;
import school.sptech.exemplo_curso.entity.curso.Curso;
import school.sptech.exemplo_curso.repository.aluno.AlunoRepository;
import school.sptech.exemplo_curso.service.curso.CursoService;

import java.util.List;

@Service
@RequiredArgsConstructor
public class AlunoService {

    private final CursoService cursoService;
    private final AlunoRepository repository;

    public List<Aluno> listar() {
        return repository.findAll();
    }

    public List<Aluno> buscarPorNomeCurso(String nome) {
        return repository.findByCursoNomeContainingIgnoreCase(nome);
    }

    public Aluno cadastrar(Aluno aluno, int cursoId){
        Curso curso = cursoService.buscarPorId(cursoId);
        aluno.setCurso(curso);
        Aluno save = repository.save(aluno);
        return save;
    }   
}
