package school.sptech.exemplo_curso.entity.aluno;

import jakarta.persistence.*;
import lombok.*;
import school.sptech.exemplo_curso.entity.curso.Curso;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Aluno {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String ra;
    private String nome;

//    private int fkCurso;
    /*
        ORM...
        @OneToOne - um para um...
        @OneToMany - um para muitos...
        @ManyToOne - muitos para um...
        @ManyToMany - muitos para muitos (associativa) CUIDADO!...
    */
    @ManyToOne
    private Curso curso;
}
