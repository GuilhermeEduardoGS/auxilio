package school.sptech.exemplo_curso.repository.curso;

import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import school.sptech.exemplo_curso.entity.aluno.Aluno;
import school.sptech.exemplo_curso.entity.curso.Curso;

import java.util.List;

public interface CursoRepository extends JpaRepository<Curso, Integer> {

    @Query("SELECT COALESCE(AVG(c.preco), 0) FROM Curso c")
    double buscarMediaPreco();
}
