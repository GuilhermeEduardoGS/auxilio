package school.sptech.exemplo_curso.repository.aluno;

import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import school.sptech.exemplo_curso.entity.aluno.Aluno;

import java.util.List;

public interface AlunoRepository extends JpaRepository<Aluno, Integer> {

    List<Aluno> findByCursoNomeContainingIgnoreCase(String nomeCurso);

    // Exemplo de JQPL
    @Query("SELECT a FROM Aluno a WHERE a.curso.nome like %:valor%")
    List<Aluno> buscarPorNomeCursoLike(String valor);

    @Modifying // Exemplo de JQPL
    @Transactional
    @Query("UPDATE Aluno a SET a.curso = NULL WHERE a.curso.id = :cursoId")
    void desvincularAlunosDoCurso(Integer cursoId);
}
