package school.sptech.exemplo_curso.controller.curso;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import school.sptech.exemplo_curso.dto.curso.CursoAtualizacaoDto;
import school.sptech.exemplo_curso.dto.curso.CursoCadastroDto;
import school.sptech.exemplo_curso.dto.curso.CursoListagemDto;
import school.sptech.exemplo_curso.dto.curso.CursoMapper;
import school.sptech.exemplo_curso.entity.curso.Curso;
import school.sptech.exemplo_curso.service.curso.CursoService;

import java.util.List;

@RestController
@RequestMapping("/cursos")
@RequiredArgsConstructor
public class CursoController {

    private final CursoService cursoService;

    @GetMapping
    public ResponseEntity<List<CursoListagemDto>> listar() {

        List<Curso> cursos = cursoService.listar();

        if (cursos.isEmpty()) {
            return ResponseEntity.status(204).build();
        }

        List<CursoListagemDto> dtos = CursoMapper.toListagemDtos(cursos);

        return ResponseEntity.status(200).body(dtos);
    }

    @GetMapping("/{id}")
    public ResponseEntity<CursoListagemDto> listarPorId(@PathVariable Integer id) {
        Curso curso = cursoService.buscarPorId(id);
        CursoListagemDto dto = CursoMapper.toListagemDto(curso);
        return ResponseEntity.status(200).body(dto);
    }

    @PostMapping
    public ResponseEntity<CursoListagemDto> cadastrar(@Valid @RequestBody CursoCadastroDto dto) {
        Curso curso = CursoMapper.toEntity(dto);
        Curso cursoSalvo = cursoService.cadastrar(curso);
        CursoListagemDto dtoSalvo = CursoMapper.toListagemDto(cursoSalvo);
        return ResponseEntity.status(201).body(dtoSalvo);
    }

    @PutMapping("/{id}")
    public ResponseEntity<CursoListagemDto> atualizar(@PathVariable Integer id, @Valid @RequestBody CursoAtualizacaoDto dto) {
        Curso curso = CursoMapper.toEntity(dto, id);
        Curso cursoAtualizado = cursoService.atualizar(curso);
        CursoListagemDto dtoAtualizado = CursoMapper.toListagemDto(cursoAtualizado);
        return ResponseEntity.status(200).body(dtoAtualizado);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> remover(@PathVariable Integer id) {
        cursoService.removerPorId(id);
        return ResponseEntity.status(204).build();
    }

    // /cursos/media-preco
    // Valor médio....
    // 0.0
    @GetMapping("/media-preco")
    public ResponseEntity<Double> buscarMedia() {
        double media = cursoService.buscarMedia();
        return ResponseEntity.status(200).body(media);
    }
}
