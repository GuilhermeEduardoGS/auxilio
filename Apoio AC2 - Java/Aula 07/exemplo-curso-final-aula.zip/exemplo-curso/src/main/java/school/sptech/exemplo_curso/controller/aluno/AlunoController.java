package school.sptech.exemplo_curso.controller.aluno;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import school.sptech.exemplo_curso.dto.aluno.AlunoCadastroDto;
import school.sptech.exemplo_curso.dto.aluno.AlunoMapper;
import school.sptech.exemplo_curso.dto.aluno.AlunoResponseDto;
import school.sptech.exemplo_curso.entity.aluno.Aluno;
import school.sptech.exemplo_curso.service.aluno.AlunoService;

import java.util.List;

@RestController // Componente do spring - Controladora
@RequiredArgsConstructor // Gera um construtor (lombok)
@RequestMapping("/alunos") // Define uma URI padrão
public class AlunoController {

    private final AlunoService service;

    // DEVERIA SER UMA DTO
    @GetMapping // ENDPOINT
    public ResponseEntity<List<AlunoResponseDto>> listar() {
        List<Aluno> alunos = service.listar();

        List<AlunoResponseDto> alunoResponseDto =
                AlunoMapper.toAlunoResponseDto(alunos);

        if (alunos.isEmpty()) {
            return ResponseEntity.status(204).build();
        }
        return ResponseEntity.status(200).body(alunoResponseDto);
    }

    // /alunos/cursos/nome?valor=xpto
    @GetMapping("/cursos/nome")
    public ResponseEntity<List<Aluno>> buscarPorNomeCurso(
            @RequestParam String valor
    ) {
        List<Aluno> alunos = service.buscarPorNomeCurso(valor);

        if (alunos.isEmpty()) {
            return ResponseEntity.status(204).build();
        }
        return ResponseEntity.status(200).body(alunos);
    }

    @PostMapping // Exemplo de cadastro
    public ResponseEntity<AlunoResponseDto> cadastrar(@RequestBody AlunoCadastroDto dto) {
        Aluno entity = AlunoMapper.toEntity(dto);
        Aluno cadastrar = service.cadastrar(entity, dto.cursoId());
        AlunoResponseDto alunoResponseDto = AlunoMapper.toAlunoResponseDto(cadastrar);
        return ResponseEntity.status(201).body(alunoResponseDto);
    }
}
