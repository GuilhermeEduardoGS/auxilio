package school.sptech.exemplo_curso.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import school.sptech.exemplo_curso.entity.Curso;

public interface CursoRepository extends JpaRepository<Curso, Integer> {

}
