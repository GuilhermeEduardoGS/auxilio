INSERT INTO Autor (nome)
VALUES
    ('Tolkien'),
    ('Oda');

INSERT INTO Livro (titulo, autor_id)
VALUES
    ('O Senhor dos Anéis: O Retorno do Rei', 1),
    ('One Piece', 2);
