package school.sptech.exemplo_relacionamento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExemploRelacionamentoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExemploRelacionamentoApplication.class, args);
	}

}
