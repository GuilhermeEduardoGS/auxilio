package school.sptech.exemplo_relacionamento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExemploRelacionamentoApplicationTests {

	@Test
	void contextLoads() {
	}

}
