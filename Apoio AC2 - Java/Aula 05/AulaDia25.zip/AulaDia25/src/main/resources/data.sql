INSERT INTO usuario (nome, email, senha)
VALUES
    ('Diego', 'diego.brito@sptech.school', 'admin'),
    ('Yoshi', 'jose.yoshiriro@sptech.school', 'admin123');